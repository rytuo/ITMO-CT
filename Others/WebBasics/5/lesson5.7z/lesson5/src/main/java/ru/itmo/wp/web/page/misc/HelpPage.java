package ru.itmo.wp.web.page.misc;

import ru.itmo.wp.web.exception.RedirectException;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@SuppressWarnings({"unused", "RedundantSuppression"})
public class HelpPage {
    private void action(HttpServletRequest request, Map<String, Object> view) {
        // No operations.
    }
}
