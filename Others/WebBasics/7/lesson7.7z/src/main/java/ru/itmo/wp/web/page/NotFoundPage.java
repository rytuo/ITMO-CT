package ru.itmo.wp.web.page;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/** @noinspection unused*/
public class NotFoundPage {
    private void action(HttpServletRequest request, Map<String, Object> view) {
        // No operations.
    }
}
